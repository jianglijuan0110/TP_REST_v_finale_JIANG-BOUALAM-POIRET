
-Ouvrir le projet "HotelREST" dans eclipse et lancer la classe "HotelRestApplication.java" \\
-Ouvrir le projet "HotelRESTClient" dans eclipse et lancer la classe "HotelRestClientApplication.java" \\
-Saisir "http://localhost:8080/hotelservice/api", suivre les indication inscrites en ligne de commande sur le terminal d'eclipse. 